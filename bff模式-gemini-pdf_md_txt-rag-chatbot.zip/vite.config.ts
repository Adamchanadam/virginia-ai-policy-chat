import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:8080', // 修正：指向 server.js 的 8080 端口
        changeOrigin: true,
        secure: false,
      },
    },
  },
});